# Gary's File Manager - Installation Guide

## Quick Start

### Option 1: Full Installation (Recommended)
```bash
pip install -r requirements.txt
```

### Option 2: Core Features Only (Minimal)
```bash
pip install -r requirements-core.txt
```

### Option 3: Custom Installation
```bash
# Install core dependencies
pip install -r requirements-core.txt

# Add optional features as needed
pip install -r requirements-optional.txt
```

## Development Setup

```bash
# Install core and development dependencies
pip install -r requirements.txt
pip install -r requirements-dev.txt

# Or use the development extras
pip install -r requirements-dev.txt
```

## System Dependencies

Some features require additional system-level dependencies:

### Windows
```powershell
# For PDF processing (optional but recommended)
# Download and install poppler from: https://github.com/oschwartz10612/poppler-windows/releases
# Add poppler/bin to your PATH

# FFmpeg (for video thumbnails)
# Download from: https://ffmpeg.org/download.html
# Add to PATH or place in application directory
```

### macOS
```bash
# Install Homebrew if not already installed
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install system dependencies
brew install ffmpeg libsndfile poppler libmagic
```

### Linux (Ubuntu/Debian)
```bash
# Install system dependencies
sudo apt update
sudo apt install ffmpeg libsndfile1-dev poppler-utils libmagic1 python3-dev

# For some distributions, also install:
sudo apt install libgl1-mesa-glx  # For OpenCV
```

### Linux (CentOS/RHEL/Fedora)
```bash
# Fedora/CentOS 8+
sudo dnf install ffmpeg libsndfile-devel poppler-utils file-devel python3-devel

# CentOS 7/RHEL 7 (requires EPEL)
sudo yum install epel-release
sudo yum install ffmpeg libsndfile-devel poppler-utils file-devel python3-devel
```

## Feature Dependencies

| Feature | Required Packages | System Dependencies |
|---------|------------------|-------------------|
| **Basic File Manager** | `PyQt5`, `psutil`, `Pillow` | None |
| **Audio Thumbnails** | `soundfile`, `pydub` | `libsndfile` (Linux/macOS) |
| **Video Thumbnails** | `ffmpeg-python`, `av`, `opencv-python` | `ffmpeg` |
| **PDF Support** | `PyMuPDF`, `pdf2image` | `poppler-utils` |
| **Office Documents** | `python-docx`, `openpyxl`, `python-pptx` | None |
| **Archive Support** | `py7zr`, `rarfile` | None |
| **Cloud Sync** | `requests`, `google-*`, `dropbox` | None |
| **Network Drives** | `pysmb`, `smbprotocol`, `paramiko` | None |
| **File Type Detection** | `python-magic` | `libmagic` |

## Troubleshooting

### Common Issues

#### ImportError: No module named 'PyQt5'
```bash
pip install PyQt5>=5.15.0
```

#### Audio processing not working
```bash
# Install audio dependencies
pip install soundfile pydub

# System dependencies (see above for your OS)
```

#### Video thumbnails not generating
```bash
# Install ffmpeg system-wide and ensure it's in PATH
# Test with: ffmpeg -version

# Install Python packages
pip install ffmpeg-python av opencv-python
```

#### PDF thumbnails not working
```bash
# Install poppler (see system dependencies above)
# Install Python packages  
pip install PyMuPDF pdf2image
```

### Performance Optimization

For better performance, consider installing these optional optimizations:

```bash
# Faster JPEG processing
pip install pillow-simd  # Instead of regular Pillow

# Faster NumPy (if using video features)
pip install numpy  # Will be installed with opencv-python

# Memory profiling (development)
pip install memory-profiler
```

## Verification

Test your installation:

```bash
# Test basic functionality
python -c "from PyQt5.QtWidgets import QApplication; print('PyQt5 OK')"

# Test audio support  
python -c "import soundfile; print('Audio OK')"

# Test video support
python -c "import cv2; print('Video OK')"

# Run the application
python garysfm_1.3.1.py
```

## Docker Installation (Alternative)

For a containerized installation:

```dockerfile
FROM python:3.9-slim

# Install system dependencies
RUN apt-get update && apt-get install -y \
    ffmpeg \
    libsndfile1-dev \
    poppler-utils \
    libmagic1 \
    libgl1-mesa-glx \
    && rm -rf /var/lib/apt/lists/*

# Install Python dependencies
COPY requirements.txt .
RUN pip install -r requirements.txt

# Copy application
COPY . /app
WORKDIR /app

# Run application
CMD ["python", "garysfm_1.3.1.py"]
```

## Environment Variables

Optional configuration via environment variables:

```bash
# Cache directory (default: system temp)
export GARYSFM_CACHE_DIR=/path/to/cache

# Debug mode
export GARYSFM_DEBUG=1

# Disable specific features
export GARYSFM_DISABLE_VIDEO=1
export GARYSFM_DISABLE_CLOUD=1
```