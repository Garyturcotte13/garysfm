# Gary's File Manager - Installation Guide
Version: 1.3.1

## Quick Start Options

### Option 1: Full Installation (Recommended)
Install all features and dependencies:
```bash
pip install -r requirements.txt
```

### Option 2: Minimal Installation
Install only core functionality (file management, basic thumbnails, encryption):
```bash
pip install -r requirements-core.txt
```

### Option 3: Custom Installation
Start with core features and add specific functionality:
```bash
# Install core features first
pip install -r requirements-core.txt

# Then add optional features as needed
pip install -r requirements-optional.txt
```

### Option 4: Development Setup
For developers and contributors:
```bash
pip install -r requirements.txt -r requirements-dev.txt
```

## Feature-Specific Installation

### Audio Features (Waveform thumbnails)
```bash
pip install soundfile pydub mutagen
```

### Video Features (Video thumbnails)
```bash
pip install ffmpeg-python av opencv-python
```

### Office Document Support
```bash
pip install python-docx openpyxl python-pptx
```

### Cloud Storage Sync
```bash
pip install google-api-python-client google-auth dropbox
```

### Network Drive Support
```bash
pip install pysmb smbprotocol paramiko
```

### Archive Support (7Z, RAR)
```bash
pip install py7zr rarfile
```

## System Dependencies

Some features require system-level software:

### Windows
```powershell
# FFmpeg for video thumbnails
# Download from: https://ffmpeg.org/download.html
# Add to PATH or place in application directory

# Poppler for PDF processing (optional)
# Download from: https://github.com/oschwartz10612/poppler-windows/releases
```

### macOS
```bash
# Install via Homebrew
brew install ffmpeg libsndfile poppler libmagic
```

### Linux (Ubuntu/Debian)
```bash
sudo apt update
sudo apt install ffmpeg libsndfile1-dev poppler-utils libmagic1 python3-dev libgl1-mesa-glx
```

### Linux (RHEL/CentOS/Fedora)
```bash
sudo dnf install ffmpeg libsndfile-devel poppler-utils file-devel python3-devel mesa-libGL
```

## Running the Application

After installation:
```bash
python garysfm_1.3.1.py
```

## Requirements Files Explained

| File | Purpose | Use Case |
|------|---------|----------|
| `requirements.txt` | Complete installation | Full-featured file manager |
| `requirements-core.txt` | Minimal installation | Basic file management only |
| `requirements-optional.txt` | Extended features | Add specific functionality |
| `requirements-dev.txt` | Development tools | For developers/contributors |

## Troubleshooting

### Common Issues

#### "No module named 'PyQt5'"
```bash
pip install PyQt5>=5.15.0
```

#### Audio features not working
```bash
# Install audio dependencies
pip install soundfile pydub mutagen
# Ensure system audio libraries are installed (see system dependencies above)
```

#### Video thumbnails not generating
```bash
# Ensure FFmpeg is installed and in PATH
ffmpeg -version

# Install video processing packages
pip install ffmpeg-python av opencv-python
```

#### PDF thumbnails not working
```bash
# Install poppler system dependency (see above for your OS)
# Install PDF processing packages
pip install PyMuPDF pdf2image
```

### Performance Notes

- **Large media collections**: Consider using SSD storage for cache directory
- **Memory usage**: Video processing can be memory-intensive
- **Network drives**: SMB/SFTP operations may be slower over network

## Virtual Environment (Recommended)

For isolated installations:
```bash
# Create virtual environment
python -m venv garysfm_env

# Activate (Windows)
garysfm_env\Scripts\activate

# Activate (macOS/Linux)
source garysfm_env/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run application
python garysfm_1.3.1.py
```

## License and Support

- **License**: See LICENSE file
- **Issues**: Report bugs and feature requests on the project repository
- **Documentation**: Additional documentation in the `mds/` folder

## Version Compatibility

- **Python**: 3.7+ (3.9+ recommended)
- **PyQt5**: 5.15.0+ required
- **Operating Systems**: Windows 10+, macOS 10.14+, Linux (modern distributions)

## What's Included

With the full installation, you get:
- ✅ Complete file management with thumbnails
- ✅ 31-language internationalization support
- ✅ Audio waveform thumbnails
- ✅ Video frame thumbnails
- ✅ PDF and office document previews
- ✅ Archive support (ZIP, 7Z, RAR)
- ✅ Cloud storage sync (Google Drive, Dropbox)
- ✅ Network drive access (SMB/CIFS, SFTP)
- ✅ File encryption/decryption
- ✅ Advanced theming system
- ✅ Mobile app (APK) analysis
- ✅ And much more!